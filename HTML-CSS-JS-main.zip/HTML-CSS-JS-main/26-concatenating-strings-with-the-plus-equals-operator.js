// Example
var ourStr = "I come first. ";
ourStr += "I come second.";

// Only change code below this line

var myStr="This is the first sentence. ";

 myStr += "This is the second sentence.";
