// Example
var ourName;

// Declare myName below this line
var myName;
