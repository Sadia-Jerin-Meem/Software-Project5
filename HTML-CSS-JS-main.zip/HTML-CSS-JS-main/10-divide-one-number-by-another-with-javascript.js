var quotient = 66 / 33;


