var myStr = '<a href="http://www.example.com" target="_blank">Link</a>';


