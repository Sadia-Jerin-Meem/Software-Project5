var sum = 10 + 10;

