// Example
var anAdjective = "awesome!";
var ourStr = "freeCodeCamp is ";
ourStr += anAdjective;

// Only change code below this line

var someAdjective="cool";
var myStr = "Learning to code is ";
myStr+= someAdjective;
