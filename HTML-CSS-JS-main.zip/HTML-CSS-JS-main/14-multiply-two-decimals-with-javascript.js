var product = 2.0 * 2.5;


