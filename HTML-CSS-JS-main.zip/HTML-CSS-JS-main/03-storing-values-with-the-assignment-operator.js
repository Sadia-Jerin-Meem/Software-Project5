// Setup
var a;
var b = 2;

// Only change code below this line
a=7;
b=a;
