// Setup
var a;
a = 7;
var b;
b = a;

// Only change code below this line
