var difference = 45 - 33;


