// Example
var ourArray = ["John", 23];

// Only change code below this line.
var myArray = ["test string",777];

